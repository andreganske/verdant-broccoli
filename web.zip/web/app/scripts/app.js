'use strict';

var verdantApp = angular.module('verdantApp', [
	'ngRoute',
	'ngAnimate',
	'ui.mask',
	'ui.bootstrap',
	'toaster',
	'verdantApp.directives',
	'verdantApp.filters',
	'verdantApp.services'
]);

verdantApp.config(function($routeProvider) {

	$routeProvider.when('/', {
		templateUrl: '',
		controller: ''
	});

	$routeProvider.otherwise({
		redirectTo: '/'
	});

});

verdantApp.run(['ParseSDK', 'location', function(service, $location) {

	// getconfig

	// validate login

}]);