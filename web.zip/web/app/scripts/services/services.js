'use strict';

angular.module('services', ['toaster'])

.factory('ParseSDK', function($location, $route, toaster) {

	Parse.initialize("5le8xMqBDw8TjbeZhkOuahmwPrbAIlVD1Pzv6u7T", "s1Zn5X4iKCmhnBf2rLpCFzA8ImW8uOdOplb1YGLO");

	var service = {

		// gets

		// sets

		// configs

	};

	return service;

});

